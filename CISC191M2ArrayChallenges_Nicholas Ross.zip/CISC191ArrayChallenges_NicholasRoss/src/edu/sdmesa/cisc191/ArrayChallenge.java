package edu.sdmesa.cisc191;

import java.lang.reflect.Array;

/**
 * Lead Author(s):
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here>>
 *  
 * Version/date: 
 * 
 * Responsibilities of class:
 * 
 */
/**
 */
public class ArrayChallenge
{
	/**
	 * Purpose: Find the largest element in the array given
	 * 
	 * @param array to search
	 * @return largest element
	 */
	public static int max(int[] array)
	{
		int max = -99999;
		for (int i=0; i<array.length; ++i) {
			if (array[i] > max) {
				max = array[i];
			}
			
		}
		return max;
	}
	
	/**
	 * Purpose: Find the smallest element in the array given
	 * 
	 * @param array to search
	 * @return smallest element
	 */
	public static int min(int[] array)
	{
		int min = array[0];
		for (int i=0; i<array.length; ++i) {
			if (array[i] < min) {
				min = array[i];
			}
			
		}
		return min;
	}
	
	/**
	 * Purpose: Find the sum of all elements in the array.
	 * 
	 * @param array to search
	 * @return the sum of the elements
	 */
	public static int sum(int[] array)
	{
		int sum = 0;
		for (int i=0;i<array.length;++i) {
			sum += array[i];
		}
		
		return sum;
	}
	
	/**
	 * Purpose: Find the average of all elements in the array.
	 * 
	 * @param array to search
	 * @return the average of the elements
	 */
	public static double average(int[] array)
	{
		double sum = 0;
		for (int i=0;i<array.length;++i) {
			sum += array[i];
		}
		double average = sum / array.length;
		return average;
	}
	
	/**
	 * Purpose: Find if the array contains the desired element.
	 * 
	 * @param array to search
	 * @return boolean
	 */
	public static boolean contains(int[] array, int match)
	{
		boolean found = false;
		int value = match;
		for (int i=0;i<array.length;++i) {
			if (array[i] == value) {
				found = true;
				break;
			}
		}
		return found;
	}
	
	/**
	 * Purpose: Return the first index of a value in the array or -1 if the value is not in the array.
	 * 
	 * @param array to search
	 * @return the desired value
	 */
	public static int find(int[] array, int match)
	{
		if (array == null)
			return -1;
		
		int i=0;
		while (i<array.length) {
			if (array[i]==match)
				return i;
			else
				i = i + 1;
		}
		return -1;
	}
	
	/**
	 * Purpose: Test if the integers are in increasing order.
	 * 
	 * @param array to search
	 * @return boolean
	 */
	public static boolean inOrder(int[] array)
	{
		boolean order = true;
		if (array == null) {
			return true;
		}
		for (int i = 0;i<array.length-1;++i) {
			if (array[i] < array[i+1]) {
				order = true;
			}
			else {
				order = false;
				break;
			}
		}
		return order;
	}
	
	/**
	 * Purpose: Moves the largest integer to the end of the array
	 * 
	 * @param array to search
	 * @return array
	 */
	public static int[] bubbleUp (int[] list) {
		int temp = 0;
		for (int i=0; i<list.length-1;++i) {
			if (list[i] > list[i+1]) {
				temp = list[i];
				list[i] = list[i+1];
				list[i+1]=temp;
			}
		}
		
		
		return list;
	}
	
	/**
	 * Purpose: Loops through the array until the elements are in increasing order.
	 * 
	 * @param array to search
	 * @return array
	 */
	public static int[] bubbleSort (int[] list) {
		int temp = 0;
		for (int i=0;i<list.length-1;i++) {
			for (int j=0;j<list.length-1-i;j++) {
				if (list[j] > list[j+1]) {
					temp = list[j];
					list[j] = list[j+1];
					list[j+1] = temp;
				}
			}
		}
		
		return list;
	}
	
	/**
	 * Purpose: Returns a new array with the same elements as the original array.
	 * 
	 * @param array to search
	 * @return array
	 */
	public static char[] copy(char[] letters) {
		
		char[] b = letters.clone();
		
		return b;
	}
	
	/**
	 * Purpose: Returns a new array with the elements in the reverse order of the original array.
	 * 
	 * @param array to search
	 * @return array
	 */
	
	public static char[] backwards(char[] forward) {
		char[] backward = new char[forward.length];
		int j = forward.length;
		for (int i=0;i<forward.length;i++) {
			backward[j-1] = forward[i];
			j=j-1;
		}
		
		return backward;
	}
	
	/**
	 * Purpose: Checks if the given array is a palindrome.
	 * 
	 * @param array to search
	 * @return boolean
	 */
	
	public static boolean isPalindrome(char[] letters) {
		
		boolean b = true;
		int j = letters.length;
		if (letters.length < 2 || (letters[0] == letters[1])) {
			
			b = true;
			
		}
		
		else {
		for (int i=0;i<=j / 2; i++) {
			if (letters[i] != letters[j-1-i]) {
				b = false;
				break;
			}
		}
	}
		
		return b;
	}
	
	/**
	 * Purpose: Counts how many times a desired element is in the given array.
	 * 
	 * @param array to search
	 * @return integer
	 */
	
	public static int countValues(char[] letters, int count) {
		if (letters.length > 0) {
			//Same code as next method; method overloading
		}
		else {
			count = 0;
		}
		return count;
	}
	
	public static int countValues(char[] letters, char ltr) {
		int count = 0;
		for (int i=0;i<letters.length;++i) {
			if (ltr == letters[i]) {
				count++;
			}
			
		}
		
		return count;
	}
	
	/**
	 * Purpose: Returns the desired element.
	 * 
	 * @param array to search
	 * @return element
	 */
	
	public static int getElement(int[][] numbers, int first, int second) {
		return numbers[first][second];
	}
	
	/**
	 * Purpose: Returns the sum of every row in the array.
	 * 
	 * @param array to search
	 * @return integer
	 */
	
	public static int sumRow(int[][] numbers, int row) {
		int sum = 0;
		for (int i=0;i<numbers[0].length;++i) {
			sum += numbers[row][i];
		}
		return sum;
	}
	
	/**
	 * Purpose: Returns the column of every row in the array.
	 * 
	 * @param array to search
	 * @return integer
	 */
	
	public static int sumColumn(int [][] numbers, int column) {
		int sum = 0;
		for (int i=0;i<numbers.length;++i) {
			sum += numbers[i][column];
		}
		
		return sum;
	}
	
	/**
	 * Purpose: Returns the sum of the elements that follow a left-to-right diagonal through the array.
	 * 
	 * @param array to search
	 * @return integer
	 */
	
	public static int sumLeftToRightDiagonal(int[][] numbers) {
		int sum = 0;
		for (int i=0;i<numbers.length;++i) {
			sum += numbers[i][i];
		}
		
		return sum;
	}
	
	/**
	 * Purpose: Returns the sum of the elements that follow a right-to-left diagonal through the array.
	 * 
	 * @param array to search
	 * @return integer
	 */
	
	public static int sumRightToLeftDiagonal(int [][] numbers) {
		int sum = 0;
		for (int i=numbers.length-1;i>=0;--i) {
			sum += numbers[i][i];
		}
		return sum;
		
	}
	
	/**
	 * Purpose: Returns the sum of the last element in each row of the array.
	 * 
	 * @param array to search
	 * @return integer
	 */
	
	public static int sumLastRowElements(int [][] numbers) {
		int sum = 0;
		for (int i=0;i<numbers.length;++i) {
			sum += numbers[i][numbers[i].length-1];
		}
		return sum;
	}
}
